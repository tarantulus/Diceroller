﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DiceRoller
{
    public class User
    {
        public string ClientId { get; set; }
        public string Name { get; set; }
    }
}